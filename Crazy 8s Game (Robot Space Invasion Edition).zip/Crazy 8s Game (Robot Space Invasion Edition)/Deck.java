import java.util.*;

class Deck {

    private Card[] deck;
    private int top;

    public Deck() {
        top = 0;
        deck = new Card[52];
        char suit[] = {'s', 'h', 'd', 'c'}; 
        int rank[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
        for (int i = 0; i < deck.length; i++) {
            deck[i] = new Card(suit[i / 13], rank[i % 13]);
        }
        shuffle();
    }

    public Card deal() {
        top++;
        return deck[top];
    }

    public boolean canDeal() {
        boolean canDeal = true;
        if(top == 51) {
            canDeal = false;
        }
        return canDeal;
    }

    public void shuffle() {
       for (int i = 0; i < 100; i++) {
           for (int j = 0; j < deck.length; j++) { 
                int random = (int) (Math.random()*52);
                Card temp = deck[j];
                deck[j] = deck[random];
                deck[random] = temp;
            } 
        }
    }
    
    public int getTop() {
        return top;
    }

    public String toString() {
       String deckToString = "";
       for(Card i : deck) {
           deckToString += (i.toString()+" , ");
       }
       return deckToString;
    }
}