class Card {
    private char suit;
    private int rank;
    
    public Card(final char suit, final int rank) {
        this.suit = suit;
        this.rank = rank;
    }
    
    public char getSuit() {
        return this.suit;
    }
    
    public int getRank() {
        return this.rank;
    }
    
    public String toString() {
        String suitToString = suitToString(getSuit());
        String rankToString = "";
        if (this.getRank() >= 11 || this.getRank() == 1) {
            rankToString = rankToString();
        }
        else {
            rankToString = Integer.toString(this.rank);
        }
        return rankToString + " of " + suitToString;
    }
    
    public String rankToString() {
        int rank = this.getRank();
        String s = "";
        if(rank == 1) {
            s = "Ace";
        }
        else if(rank == 11) {
            s = "Jack";
        }
        else if(rank == 12) {
            s = "Queen";
        }
        else if(rank == 13) {
            s = "King";
        }
        return s;
    }
    
    public String suitToString(char c) {
        String[] array = {"Spades", "Hearts", "Diamonds", "Clubs"};
        String[] array2 = {"s", "h", "d", "c"};
        String string = Character.toString(c);
        String s = "";
        for(int i = 0; i < 4; i++) {
            if(string.equals(array2[i])) {
                s = array[i];
            }
        }
        return s;
    }
}