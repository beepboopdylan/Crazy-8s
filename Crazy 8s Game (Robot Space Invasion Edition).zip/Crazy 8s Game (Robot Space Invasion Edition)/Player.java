import java.util.ArrayList;
import java.util.Scanner;

class Player{
    
    private ArrayList<Card> hand;
    private Scanner input;

    public Player() {
        input = new Scanner(System.in);
        hand = new ArrayList<Card>();
    }

    public void addCard(Card c) {
        hand.add(c);
    }

    public Card playsTurn(Deck deck) {
        Card theCard = null;
        System.out.println("Type 'draw' to draw a card, or type the number" + 
        " next to the card in your hand that you wish to play!" + "\n" +
        "Your current deck:\n" + handToString());
        String card = input.nextLine();
        while(card.equals("draw") && deck.canDeal()) {
            hand.add(deck.deal());
            System.out.println("Your current deck:\n" + handToString());
            card = input.nextLine();
            if(deck.getTop() == 51) {
                return theCard;
            }
        }
        int cardNumber = Integer.parseInt(card);
        theCard = hand.get(cardNumber - 1);
        System.out.println("You played: " + theCard.toString());
        hand.remove(cardNumber-1);
        return theCard;
    }
    
    public ArrayList<Card> getHand() {
        return hand;
    }

    public int getHandSize() {
        int sizeOfHand = hand.size();
        return sizeOfHand;
    }

    public String handToString() {
        String description = "";
        for (int i = 0; i < hand.size(); i++) {
            Card currentCard = hand.get(i);
            String curCard = currentCard.toString();
            description += (i+1) + "\t" + String.format("%-20s",curCard) + "\n";
        }
        return description;
    }

    public void wrongMoveRobot1() {
        System.out.println("       _______");
        System.out.println("     _/       \\_");
        System.out.println("    / |       | \\");
        System.out.println("   /  |__   __|  \\");
        System.out.println("  |__/((o| |o))\\__|");
        System.out.println("  |      | |      |");
        System.out.println("  |\\     |_|     /|");
        System.out.println("  | \\           / |");
        System.out.println("   \\| /  ___  \\ |/");
        System.out.println("    \\ | / _ \\ | /   Watch it buddy. Wrong move."+
                                                    " Try again...");
        System.out.println("     \\_________/");
        System.out.println("      _|_____|_");
        System.out.println(" ____|_________|____");
        System.out.println("/                   \\"+"\n");
    }

    public void wrongMoveRobot2() {
        System.out.println(String.format("%71s","       _______"));
        System.out.println(String.format("%73s","     _/       \\_"));
        System.out.println(String.format("%74s","    / |       | \\"));
        System.out.println(String.format("%75s","   /  |__   __|  \\"));
        System.out.println(String.format("%76s","  |__/((o| |o))\\__|"));
        System.out.println(String.format("%76s","  |      | |      |"));
        System.out.println(String.format("%76s","  |\\     |_|     /|"));
        System.out.println(String.format("%76s","  | \\           / |"));
        System.out.println(String.format("%75s","   \\| /  ___  \\ |/"));
        System.out.println(String.format("%99s","    \\ | / _ \\ | / "+
        "  You dare challenge me?"));
        System.out.println(String.format("%73s","     \\_________/"));
        System.out.println(String.format("%72s","      _|_____|_"));
        System.out.println(String.format("%77s"," ____|_________|____"));
       System.out.println(String.format("%79s","/                   \\"+"\n"));
    }

    public void wrongMoveRobot3() {
        System.out.println(String.format("%71s","       _______"));
        System.out.println(String.format("%73s","     _/       \\_"));
        System.out.println(String.format("%74s","    / |       | \\"));
        System.out.println(String.format("%75s","   /  |__   __|  \\"));
        System.out.println(String.format("%76s","  |__/((o| |o))\\__|"));
        System.out.println(String.format("%76s","  |      | |      |"));
        System.out.println(String.format("%76s","  |\\     |_|     /|"));
        System.out.println(String.format("%76s","  | \\           / |"));
        System.out.println(String.format("%75s","   \\| /  ___  \\ |/"));
        System.out.println(String.format("%119s","    \\ | / _ \\ | / "+
        "  MWAHAHAHA! You will never win, puny human!"));
        System.out.println(String.format("%73s","     \\_________/"));
        System.out.println(String.format("%72s","      _|_____|_"));
        System.out.println(String.format("%77s"," ____|_________|____"));
       System.out.println(String.format("%79s","/                   \\"+"\n"));
    }
    
    public void wrongMoveRobot4() {
        System.out.println(String.format("%71s","       _______"));
        System.out.println(String.format("%73s","     _/       \\_"));
        System.out.println(String.format("%74s","    / |       | \\"));
        System.out.println(String.format("%75s","   /  |__   __|  \\"));
        System.out.println(String.format("%76s","  |__/((o| |o))\\__|"));
        System.out.println(String.format("%76s","  |      | |      |"));
        System.out.println(String.format("%76s","  |\\     |_|     /|"));
        System.out.println(String.format("%76s","  | \\           / |"));
        System.out.println(String.format("%75s","   \\| /  ___  \\ |/"));
        System.out.println(String.format("%103s","    \\ | / _ \\ | / "+
        "  NOOOOOOOOOOOOOOOOOOOOOOOO!"));
        System.out.println(String.format("%73s","     \\_________/"));
        System.out.println(String.format("%72s","      _|_____|_"));
        System.out.println(String.format("%77s"," ____|_________|____"));
       System.out.println(String.format("%79s","/                   \\"+"\n"));
    }
} // end
