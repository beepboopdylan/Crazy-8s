import java.util.Scanner;
import java.util.ArrayList;

class Game {

    private char currentSuit;
    private Card faceup; 
    private Scanner input;
    private Player p1;
    private ArrayList<Card> compHand;
    private Deck cards;

    public Game() {
        input = new Scanner(System.in);
        cards = new Deck();
        faceup = cards.deal();
        this.currentSuit = faceup.getSuit();
        compHand = new ArrayList<Card>();
        p1 = new Player();
        for (int i = 0; i < 7; i++) {
            compHand.add(cards.deal());
            p1.addCard(cards.deal());
        }
    }

    public boolean play() {
        introduction();
        while(cards.canDeal()||p1.getHandSize()!=0||compHand.size()!=0) {
            System.out.println("UP CARD: "+faceup+"\n"+"CURRENT SUIT: "+
            faceup.suitToString(this.currentSuit) +"\n");
           if(cards.canDeal()==false||p1.getHandSize()==0||compHand.size()==0) {
                break;
            }
            Card x = p1.playsTurn(cards);
            if(x == null) {
                break;
            }
            x = checkIfValid(x);
            faceup = x;
            currentSuit = x.getSuit();
            if(faceup.getRank() == 8) {
                chooseSuit();
            }
            Card compCard = computerTurn();
            if (compCard == null) {
                break;
            }
        }
        return endGameOrContinue();
    }

    private void introduction() {
        System.out.println("");
        System.out.println(String.format("%85s", "!∞-*-∞ WELCOME TO CRAZY 8s"+
        " ∞-*-∞!"));
        System.out.println(String.format("%90s","(Robot Space Invasion" +  
        " Edition 🛸 👽 🤖 )"));
        p1.wrongMoveRobot2();
        System.out.println("The year is 3023...Earth is colonized by " + 
        "robots from space, products of our own creation. They are " +
        "slowly eradicating every human on the planet." + "\n");
        System.out.println("You are a part of an underground group of "+
        "humans leading a rebellion against Earth's robotic overlords," + 
        " and for all your life, you have been training" +
        " to deactivate them by the only way possible...through a game of" + 
        " Crazy Eights!" + "\n");
        System.out.println("This is your last chance. Make it count. You" +
        " are the final hope of humanity..." + "\n");
        System.out.println("Rules: You have 7 cards. You have to match a card"+
        " in your hand to the faceup card either by rank or suit. If you get"+
        " a !!!*~CRAZY 8~*!!!, you can choose to switch the current suit." +
        " If you run out of cards, you win! If the deck runs out, the player"+
        " with the fewest card left in their hand wins." + "\n");
        System.out.println("Here goes nothing. Good luck!" + "\n");
    }    
    
    private Card computerTurn() {
        boolean isInHand = false;
        Card theCard = null;
        while(isInHand == false) {
            int count = 0;
            for(Card i : compHand) {
                if(i.getRank()==faceup.getRank()||i.getSuit()==this.currentSuit
                &&i.getRank()!=8) {
                    theCard = compAddCard1(theCard,count);
                    isInHand = true;
                    return theCard;
                }
                else if(i.getRank() == 8) {
                    theCard = compAddCard2(theCard,count);
                    isInHand = true;
                    return theCard;
                }
            count++;
            }
            if(cards.getTop() == 51) {
                break;
            }
            System.out.println("🤖 is drawing from stock pile...");
            compHand.add(cards.deal());
        }
        return theCard;
    }

    private void chooseSuit() {
        System.out.println("You picked a !!!*~CRAZY 8~*!!! Pick a suit: ");
        String description = "";
        String[] suits = {"Spades","Hearts","Diamonds","Clubs"};
        for(int i = 1; i < 5; i++) {
            description += (i)+"\t"+String.format("%-20s",suits[i-1])+"\n";
        }
        //formatting
        System.out.println(description);
        int playerSuit = input.nextInt();
        if(playerSuit == 1) {
            this.currentSuit = 's'; 
        }
        else if(playerSuit == 2) {
            this.currentSuit = 'h';
        }
        else if(playerSuit == 3) {
            this.currentSuit = 'd';
        }
        else if(playerSuit == 4) {
            this.currentSuit = 'c';
        }
        System.out.println("You changed the current suit to: "
        +faceup.suitToString(this.currentSuit));
    }

    private void youLose() {
        if(p1.getHandSize() == 0) {
            System.out.println("\n"+"You have no more cards in your deck."
            + "\n");
            System.out.println("Woohoo! Humanity is saved. You won!!");
            p1.wrongMoveRobot4();
        }
        else if(compHand.size() == 0) {
            System.out.println("\n"+"🤖 has no more cards in its deck."+ "\n");
            System.out.println("Oh no! 🤖 won! Run away before it kills" +
            " you!");
            p1.wrongMoveRobot3();
        }
        else if(cards.getTop() == 51) { //more than 51, which is the last card
            if (p1.getHandSize() < compHand.size()) {
                System.out.println("\n"+"The deck has been exhausted, and you"+
                " have fewer cards than 🤖 ."+"\n");
                System.out.println("Woohoo! Humanity is saved. You won!!");
                p1.wrongMoveRobot4();
            }
            else {
                System.out.println("\n"+"The deck has been exhausted, and you"+
                " have more cards than 🤖 ."+"\n");
                System.out.println("Oh no! Robot won! Run away before it" +
                " kills you!");
                p1.wrongMoveRobot3();
            }
        }
    }

    private void robotChangeSuit() {
        System.out.println("🤖 got a crazy 8.");
        System.out.println("🤖 changed the current suit!" + "\n");
        char[] suitArray = {'s','h','d','c'};
        this.currentSuit = suitArray[(int)(Math.random()*4)];
    }

    private Card checkIfValid(Card x) {
        while(x.getSuit() != this.currentSuit && x.getRank() != faceup.getRank()
        &&x.getRank() != 8) {
            p1.addCard(x);
            p1.wrongMoveRobot1();
            x = p1.playsTurn(cards);
        }
        while(faceup.getRank() == 8 && x.getSuit() != this.currentSuit) {
            p1.addCard(x);
            p1.wrongMoveRobot1();
            x = p1.playsTurn(cards);
        }
        return x;
    }

    private Card compAddCard1(Card theCard, int count) {
        theCard = compHand.get(count);
        compHand.remove(count);
        System.out.println("🤖 played: "+theCard.toString()+"\n");
        faceup = theCard;
        currentSuit = theCard.getSuit();
        return theCard;
    }

    private Card compAddCard2(Card theCard, int count) {
        theCard = compHand.get(count);
        compHand.remove(count);
        System.out.println("🤖 played: "+theCard.toString()+"\n");
        robotChangeSuit();
        faceup = theCard;
        return theCard;
    }

    private boolean endGameOrContinue() {
        youLose();
        boolean shouldContinue = false;
        System.out.println("Wanna to continue playing? 'yes' or 'no'");
        String yesOrNo = input.next();
        if(yesOrNo.equals("yes")) {
            shouldContinue = true;
        }
        return shouldContinue;
    }
}